﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

//ImageProcessing Application Student Version
//Created by Mr. Iannotta for ICS4U

namespace ImageProcessing
{
    public partial class frmMain : Form
    {
        private Color[,] original; //this is the original picture - never change the values stored in this array
        private Color[,] transformedPic;  //transformed picture that is displayed

        public frmMain()
        {
            InitializeComponent();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            //this method draws the transformed picture
            //what ever is stored in transformedPic array will
            //be displayed on the form

            base.OnPaint(e);

            Graphics g = e.Graphics;

            //only draw if picture is transformed
            if (transformedPic != null)
            {
                //get height and width of the transfrormedPic array
                int height = transformedPic.GetUpperBound(0)+1;
                int width = transformedPic.GetUpperBound(1) + 1;

                //create a new Bitmap to be dispalyed on the form
                Bitmap newBmp = new Bitmap(width, height);
                for (int i = 0; i < height; i++)
                {
                    for (int j = 0; j < width; j++)
                    {
                        //loop through each element transformedPic and set the 
                        //colour of each pixel in the bitmalp
                        newBmp.SetPixel(j, i, transformedPic[i, j]);
                    }

                }
                //call DrawImage to draw the bitmap
                g.DrawImage(newBmp, 0, 20, width, height);
            }
            
        }


        private void mnuFileOpen_Click(object sender, EventArgs e)
        {
            //this method reads in a picture file and stores it in an array

            //try catch should handle any errors for invalid picture files
            try
            {

                //open the file dialog to select a picture file

                OpenFileDialog fd = new OpenFileDialog();

                //create a bitmap to store the file in
                Bitmap bmp;

                if (fd.ShowDialog() == DialogResult.OK)
                {
                    //store the selected file into a bitmap
                    bmp = new Bitmap(fd.FileName);

                    //create the arrays that store the colours for the image
                    //the size of the arrays is based on the height and width of the bitmap
                    //initially both the original and transformedPic arrays will be identical
                    original = new Color[bmp.Height, bmp.Width];
                    transformedPic = new Color[bmp.Height, bmp.Width];

                    //load each color into a color array
                    for (int i = 0; i < bmp.Height; i++)//each row
                    {
                        for (int j = 0; j < bmp.Width; j++)//each column
                        {
                            //assign the colour in the bitmap to the array
                            original[i, j] = bmp.GetPixel(j, i);
                            transformedPic[i, j] = original[i, j];
                        }
                    }
                    //this will cause the form to be redrawn and OnPaint() will be called
                    this.Refresh();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Loading Picture File. \n" + ex.Message);
            }
            
        }

        private void mnuProcessDarken_Click(object sender, EventArgs e)
        {
            //code to Darken
            if (transformedPic!= null)
            {
                int Red, Green, Blue;
                for (int i =0; i < transformedPic.GetLength(0);i++)
                {
                    for(int j=0; j < transformedPic.GetLength(1);j++)
                    {
                        Red = transformedPic[i, j].R-10;
                        if (Red < 0) 
                            Red = 0;
                        Green = transformedPic[i, j].G - 10;
                        if (Green < 0)
                            Green = 0;
                        Blue = transformedPic[i, j].B - 10;
                        if (Blue < 0)
                            Blue = 0;

                        transformedPic[i, j] = Color.FromArgb(Red, Green, Blue);
                    }
                }    


            }




            this.Refresh();
        }

        private void mnuProcessInvert_Click(object sender, EventArgs e)
        {
            //code to Invert
            
            if (transformedPic != null)
            {
                int Red, Green, Blue;
                for (int i = 0; i < transformedPic.GetLength(0); i++)
                {
                    for (int j = 0; j < transformedPic.GetLength(1); j++)
                    {
                        Red = 255 - transformedPic[i, j].R ;
                        if (Red < 0)
                            Red = 0;
                        Green = 255- transformedPic[i, j].G ;
                        if (Green < 0)
                            Green = 0;
                        Blue = 255 - transformedPic[i, j].B ;
                        if (Blue < 0)
                            Blue = 0;

                        transformedPic[i, j] = Color.FromArgb(Red, Green, Blue);
                    }
                }


            }

            this.Refresh();
        }

        private void mnuProcessWhiten_Click(object sender, EventArgs e)
        {
            //code to Whiten
            // cap is 255 
            // add 10
            this.Refresh();


            if (transformedPic != null)
            {
                int Red, Green, Blue;
                for (int i = 0; i < transformedPic.GetLength(0); i++)
                {
                    for (int j = 0; j < transformedPic.GetLength(1); j++)
                    {
                        Red = transformedPic[i, j].R + 10;
                        if (Red  >255)
                            Red = 255;
                        Green = transformedPic[i, j].G + 10;
                        if (Green > 255)
                            Green = 255;
                        Blue = transformedPic[i, j].B + 10;
                        if (Blue > 255)
                            Blue = 255;

                        transformedPic[i, j] = Color.FromArgb(Red, Green, Blue);
                    }
                }
            }
        }
        private void mnuProcessRotate_Click(object sender, EventArgs e)
        {
            //code to Rotate
            this.Refresh();
        }

        private void mnuProcessReset_Click(object sender, EventArgs e)
        {
            //code to Reset
            this.Refresh();
          
            
        }

        private void mnuProcessFlipX_Click(object sender, EventArgs e)
        {
            //code to FlipX
            this.Refresh();
            Color Pixel;
            for (int i = 0; i < transformedPic.GetLength(0) ; i++)
            {
                for (int j = 0; j < transformedPic.GetLength(1)/2; j++)
                {
                    Pixel = transformedPic[i, j];
                    transformedPic[i, j] = transformedPic[i, transformedPic.GetLength(0) - 1 - i];
                    transformedPic[i,transformedPic.GetLength(0) - 1 - i] = Pixel;

                }
            }

        }

        private void mnuProcessFlipY_Click(object sender, EventArgs e)
        {
            //code to FlipY
            this.Refresh();
            Color Pixel;
            for (int i = 0; i < transformedPic.GetLength(0) / 2; i++)
            {
                for (int j = 0; j < transformedPic.GetLength(1) ; j++)
                {
                    Pixel = transformedPic[i, j];
                    transformedPic[i, j] = transformedPic[transformedPic.GetLength(0) -1-i, j];
                    transformedPic[transformedPic.GetLength(0) -1- i, j] = Pixel;

                }
            }


        }

        private void mnuProcessMirrorH_Click(object sender, EventArgs e)
        {
            //code to Mirror Horizontally
            this.Refresh();
        }

        private void mnuProcessMirrorV_Click(object sender, EventArgs e)
        {
            //code to Mirror Vertically
            this.Refresh();
        }

        private void mnuProcessScale50_Click(object sender, EventArgs e)
        {
            //code to Scale 50%
            this.Refresh();
        }

        private void mnuProcessScale200_Click(object sender, EventArgs e)
        {
            //code to Scale 200%
            this.Refresh();
        }

        private void mnuProcessBlur_Click(object sender, EventArgs e)
        {
            //code to Blur
            this.Refresh();
        }


    }
}
